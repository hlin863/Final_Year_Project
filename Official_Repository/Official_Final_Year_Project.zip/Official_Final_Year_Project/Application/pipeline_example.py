"""
import the necessary packages.
"""

import sys # import the sys module
import time # import time module to track the modification time.
import logging # import the logging to track the changes in the folder

from sklearn.datasets import load_digits # import the load_digits library

mnist = load_digits() # load the mnist dataset

from sklearn.pipeline import Pipeline # use sklearn for the machine learning pipeline libraries.

from sklearn.model_selection import train_test_split # import the train_test_split function from sklearn to divide the data into training and testing sets.

from sklearn.preprocessing import StandardScaler # import the standard scaler library from sklearn

from imputer import Imputer # import the imputer library
from scaler import Scaler # import the scaler library
from encoder import Encoder # import the encoder library

from sklearn.linear_model import LogisticRegression # import the logistic regression model

from sklearn.metrics import accuracy_score # import the accuracy score library from sklearn to calculate the pipeline score

from watchdog.observers import Observer  #creating an instance of the watchdog.observers.Observer from watchdogs class.
from watchdog.events import LoggingEventHandler  #implementing a subclass of watchdog.events.FileSystemEventHandler which is LoggingEventHandler in our case

def data_division(X, y, test_size):

    """
    The function aims to divide the data into the training and the testing sets
    """

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, random_state=42) # divide the data into training and testing sets

    return X_train, X_test, y_train, y_test # return the training and testing sets

X, y = mnist.data, mnist.target # assign the data and the target to the variables X and y

X_train, X_test, y_train, y_test = data_division(X, y, test_size=0.1) # call the data_division function

"""

Test function to display the training and testing sets

"""

print("X shape: ", X.shape) # test the display for the input data size.

print("y shape: ", y.shape) # test the display for the output data size.

print("X_train shape: ", X_train.shape) # test the display for the input training data size.

print("y_train shape: ", y_train.shape) # test the display for the output training data size.

def create_pipeline(model, X, y):

    """
    The function aims to create a pipeline for the data and model
    @param model: The model to be used in the pipeline
    @param X: The data to be used in the pipeline
    @param y: The labels to be used in the pipeline
    """

    pipe = Pipeline([('scaler', StandardScaler()),
    ('model', model)]) # create the pipeline

    pipe.fit(X, y) # fit the pipeline to the data. 

    model.fit(X, y) # fit the model to the data

    return pipe # return the pipeline

def pipeline_score(pipe, X, y):

    """
    The function aims to calculate the score of the pipeline
    @param pipe: The pipeline to be used
    @param X: The data to be used in the pipeline
    @param y: The labels to be used in the pipeline
    """

    y_pred = pipe.predict(X) # predict the labels for the data

    score = accuracy_score(y, y_pred) # calculate the accuracy score

    print("The accuracy score for the pipeline is: ", score) # display the accuracy score

    return score # return the score

logistic_regression = LogisticRegression(max_iter= 10000) # create the logistic regression model

pipe = create_pipeline(logistic_regression, X_train, y_train) # call the create_pipeline function

pipeline_score(pipe, X_test, y_test) # call the pipeline_score function

def track_changes():
    """
    
    This function aims to track any changes made in this folder.
    
    """

    logging.basicConfig(level=logging.INFO,
                        format='%(asctime)s - %(message)s') # logs the time of modification and the messages.
    path = sys.argv[1] if len(sys.argv) > 1 else '.' # sets the path to the current directory.
    event_handler = LoggingEventHandler() # creates an instance of the LoggingEventHandler class to track the events.
    observer = Observer() # imports the observer class from the watchdog.observers module.
    observer.schedule(event_handler, path, recursive=True)  #Scheduling monitoring of a path with the observer instance and event handler. There is 'recursive=True' because only with it enabled, watchdog.observers.Observer can monitor sub-directories
    observer.start()  #for starting the observer thread
    try:
        while True:
            time.sleep(1) # wait 1 second before checking for changes
    except KeyboardInterrupt:
        observer.stop() # stop the observer thread
    observer.join() # join the observer thread

track_changes() # call the track_changes function