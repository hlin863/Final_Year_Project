from models import train

if __name__ == '__main__':
    train = train.Train()
    train.main()